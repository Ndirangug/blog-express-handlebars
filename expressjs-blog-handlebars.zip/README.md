# Blog-express-handlebars

Blog with Express Js and Express Handlebars

<p>This is an  Blog, which is made using Express Js and Express Handlebars.

## Installation

```bash
yarn install

#or if using npm
npm install
```

## Usage

```bash
yarn dev

#or if using npm
npm run dev
```
